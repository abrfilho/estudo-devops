#!/bin/bash

docker run -itd -p 80:3000 abrfilho/app-dcw5:develop